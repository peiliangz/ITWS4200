Name: Peiliang Zou
RCS: zoup
RIN: 661412298

1. Nodejs Portion
Please see my twitter.js which I used express framework to create a node server
and use twitter module to get tweets information via Twitter API. I save the tweets
information in the tweet-conventions.json file.



2. interface portion
I deployed the Angularjs framework to create a web page with a input field and button. Everytime
user input a quantity and click the submit button, the exact quantity of tweets will be displayed
on index.html page. However, please run index.html page on the localserver, for example using Apache,
otherwise the json file could not be found.


3. Output portion
I have created a valid json file called tweet-conventions.json. I already used this static json file in
the index.html page.
