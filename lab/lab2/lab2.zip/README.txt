RIN: 661412298
Name: Peiliang Zou


I designed this weather application using OpenWeatherMap API to get weather information. And I use HTML5 Geolocaton API to get user's location. I also elaborate my html page with Bootstrap.
Plus I added a footer on my page declaring the sources that I used for this app.  

Please notice that open this html page in safari, or if you want to use chrome, make sure create a folder under you xampp/htdoc folder, otherwise it won't let you get your geoloation infomation. 

